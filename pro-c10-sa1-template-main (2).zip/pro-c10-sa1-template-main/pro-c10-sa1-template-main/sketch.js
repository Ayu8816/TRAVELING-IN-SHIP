var weight = [30,35,40,45]
var average,sum 
function average()
{ 
  sum = weight[0] + weight[1] + weight[2] + weight[3];
  average = sum/weight.length;

  console.log(average);
}

function setup() 
{
  createCanvas(400,400);
  average();
}

function draw() 
{
background(51);

}

